-- Banco de Dados: canes_finance
CREATE DATABASE IF NOT EXISTS canes_finance
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

USE canes_finance;

DROP TABLE IF EXISTS transactions;
DROP TABLE IF EXISTS clients;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS accounts;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','client') NOT NULL DEFAULT 'client',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE accounts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  type ENUM('caixa','banco','cartao','outro') NOT NULL DEFAULT 'banco',
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  type ENUM('receita','despesa') NOT NULL,
  description VARCHAR(255)
) ENGINE=InnoDB;

CREATE TABLE transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  trx_date DATE NOT NULL,
  description VARCHAR(255),
  amount DECIMAL(14,2) NOT NULL,
  trx_type ENUM('credit','debit') NOT NULL,
  account_id INT NOT NULL,
  category_id INT,
  created_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (account_id) REFERENCES accounts(id) 
      ON DELETE RESTRICT ON UPDATE CASCADE,
  FOREIGN KEY (category_id) REFERENCES categories(id) 
      ON DELETE SET NULL ON UPDATE CASCADE,
  FOREIGN KEY (created_by) REFERENCES users(id) 
      ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE clients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(120),
  phone VARCHAR(50),
  address TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Usuário admin (senha = admin123)
INSERT INTO users (username, full_name, email, password_hash, role) VALUES
('admin','Administrador Canes','admin@canes.local',
'$2b$12$3w/REuVyoe8bnAuwnGlAmO3Phk3mKeiQ2qP9T1Ryls6zQ5cXn0TWu','admin');

INSERT INTO accounts (name,type,description) VALUES
('Conta Banco','banco','Conta corrente da empresa'),
('Caixa','caixa','Dinheiro em caixa');

INSERT INTO categories (name,type,description) VALUES
('Venda','receita','Receita de vendas'),
('Aluguel','despesa','Pagamento de aluguel'),
('Salário','despesa','Pagamento de salários');

INSERT INTO transactions (trx_date,description,amount,trx_type,account_id,category_id,created_by) VALUES
('2025-09-01','Venda cliente A',5000.00,'credit',1,1,1),
('2025-09-03','Pagamento aluguel',1200.00,'debit',1,2,1),
('2025-09-04','Pagamento salários',2500.00,'debit',1,3,1),
('2025-09-05','Venda em dinheiro',1500.00,'credit',2,1,1),
('2025-09-06','Compra materiais',300.00,'debit',2,3,1),
('2025-09-07','Serviço prestado - cliente B',800.00,'credit',1,1,1);

INSERT INTO clients (name,email,phone,address) VALUES
('Cliente A','clienteA@email.com','1199999-1111','Rua das Flores, 123'),
('Cliente B','clienteB@email.com','1198888-2222','Av. Paulista, 456');
